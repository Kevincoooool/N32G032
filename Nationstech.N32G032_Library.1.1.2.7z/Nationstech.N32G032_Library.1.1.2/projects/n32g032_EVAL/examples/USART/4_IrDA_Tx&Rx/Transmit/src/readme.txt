/**
  @page USART_IrDA_Tx USART IrDA_Tx example
  
  @verbatim
  ******************************************************************************
  * @file    USART/IrDA_Tx/src/readme.txt 
  * @author  
  * @version V1.0.0
  * @date    
  * @brief   Description of the USART IrDA_Tx example.
  ******************************************************************************

   @endverbatim


@par Example Description 

This example provides a basic communication between Board1_USARTy and Board2_USARTz
using flags.USARTy and USARTz can be USART1 and USART2.

First, the Board1_USARTy sends TxBuffer to Board2_USARTz. The Board2_USARTz reads 
the received data and store it into RxBuffer.
The received data is then compared with the send ones and the result of this 
comparison is stored in the "TransferStatus" variable.   

USARTy and USARTz configured as follow:
  - BaudRate = 1200 baud  
  - Word Length = 8 Bits
  - One Stop Bit
  - No parity
  - Hardware flow control disabled (RTS and CTS signals)
  - Receive and transmit enabled
  
USARTy and USARTz PINs connection as follow:
  - USART1_Tx.PA9    <------->   USART2_Rx.PB7
  