/**
  @page USART_HalfDuplex USART HalfDuplex example
  
  @verbatim
  ******************************************************************************
  * @file    USART/HalfDuplex/src/readme.txt 
  * @author  
  * @version V1.0.0
  * @date    
  * @brief   Description of the USART HalfDuplex example.
  ******************************************************************************

   @endverbatim


@par Example Description 

This example provides a basic communication between USARTy and USARTz in 
Half-Duplex mode using flags. USARTy and USARTz can be USART1 and USART2.

First, the USARTy sends TxBuffer to USARTz. The USARTz reads the received data and
store it into RxBuffer.
The received data is then compared with the send ones and the result of this 
comparison is stored in the "TransferStatus" variable.   

USARTy and USARTz configured as follow:
  - BaudRate = 115200 baud  
  - Word Length = 8 Bits
  - One Stop Bit
  - No parity
  - Hardware flow control disabled (RTS and CTS signals)
  - Receive and transmit enabled
  
USARTy and USARTz PINs connection as follow:
  - USART1_Tx.PA9    <------->   USART2_Tx.PB6
  