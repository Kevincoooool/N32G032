/**
  @page USART_Interrupt USART Interrupt example
  
  @verbatim
  ******************************************************************************
  * @file    USART/Interrupt/src/readme.txt 
  * @author  
  * @version V1.0.0
  * @date    
  * @brief   Description of the USART Interrupt example.
  ******************************************************************************

   @endverbatim


@par Example Description 

This example provides a basic communication between USARTy and USARTz using Interrupt.
USARTy and USARTz can be USART1 and UART6 or UART5 and USART2.

First, the USARTy sends TxBuffer to USARTz. The USARTz reads the received data and
store it into RxBuffer.
The received data is then compared with the send ones and the result of this 
comparison is stored in the "TransferStatus" variable.   

USARTy and USARTz configured as follow:
  - BaudRate = 115200 baud  
  - Word Length = 8 Bits
  - One Stop Bit
  - No parity
  - Hardware flow control disabled (RTS and CTS signals)
  - Receive and transmit enabled
  
USARTy and USARTz PINs connection as follow:
  - USART1_Tx.PA9     <------->   UART6_Rx.PA5
  - USART1_Rx.PA10    <------->   UART6_Tx.PA4
  or
  - UART5_Tx.PB0    <------->   USART2_Rx.PA10
  - UART5_Rx.PB1    <------->   USART2_Tx.PA9
  