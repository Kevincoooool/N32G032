/**
  @page USART_DMA_Interrupt USART DMA_Interrupt example
  
  @verbatim
  ******************************************************************************
  * @file    USART/DMA_Interrupt/src/readme.txt 
  * @author  
  * @version V1.0.0
  * @date    
  * @brief   Description of the USART DMA_Interrupt example.
  ******************************************************************************

   @endverbatim


@par Example Description 

This example provides a basic communication between USARTy and USARTz using DMA 
capability. USARTy and USARTz can be USART1 and USART2.

First, the DMA transfers data from TxBuffer2 buffer to USARTz Transmit data 
register, then this data is sent to USARTy. Data received by USARTy is transferred
by DMA and stored in RxBuffer1 then compared with the send ones and the result 
of this comparison is stored in the "TransferStatus1" variable.
 
In the same time, the DMA transfers data from TxBuffer1 buffer to USARTy Transmit
data register, then this data is sent to USARTz. Data received by USARTz is
transferred by DMA and stored in RxBuffer2 then compared with the send ones and
the result of this comparison is stored in the "TransferStatus2" variable.    

USARTy and USARTz configured as follow:
  - BaudRate = 115200 baud  
  - Word Length = 8 Bits
  - One Stop Bit
  - No parity
  - Hardware flow control disabled (RTS and CTS signals)
  - Receive and transmit enabled
  
USARTy and USARTz PINs connection as follow:
  - USART1_Tx.PA9    <------->   USART2_Rx.PB7
  - USART1_Rx.PA10   <------->   USART2_Tx.PB6
  