/**
  @page USART_MultiProcessor USART MultiProcessor example
  
  @verbatim
  ******************************************************************************
  * @file    USART/MultiProcessor/src/readme.txt 
  * @author  
  * @version V1.0.0
  * @date    
  * @brief   Description of the USART MultiProcessor example.
  ******************************************************************************

   @endverbatim


@par Example Description 

This example provides a description of how to use the USART in multi-processor mode.
USARTy and USARTz can be USART1 and UART6.

First, the USARTy and USARTz address are set to 0x1 and 0x2. The USARTy send 
continuously the character 0x33 to the USARTz. The USARTz toggle LED1, LED2 
and LED3 pins while receiving 0x33.

When a falling edge is applied on BUTTON_KEY EXTI line, an interrupt is generated
and in the EXTI0_IRQHandler routine(the ControlFlag = 0), the USARTz is entered in 
mute mode and still in this mode (no LED toggling) until a rising edge is applied 
on BUTTON_KEY EXTI Line 0(the ControlFlag = 1).
In this interrupt routine the USARTy send the character of address mark (0x102)
to wakeup USARTz. The LED restart toggling.

USARTy and USARTz configured as follow:
  - BaudRate = 115200 baud  
  - Word Length = 9 Bits
  - One Stop Bit
  - No parity
  - Hardware flow control disabled (RTS and CTS signals)
  - Receive and transmit enabled
  
USARTy and USARTz PINs connection as follow:
  - USART1_Tx.PA9    <------->   UART6_Rx.PA5
  - USART1_Rx.PA10   <------->   UART6_Tx.PA4
  