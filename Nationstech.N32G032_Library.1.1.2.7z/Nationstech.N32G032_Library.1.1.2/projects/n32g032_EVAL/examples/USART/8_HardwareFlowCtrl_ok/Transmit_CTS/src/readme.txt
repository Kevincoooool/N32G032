/**
  @page USART_Transmit_CTS USART Transmit_CTS example
  
  @verbatim
  ******************************************************************************
  * @file    USART/Transmit_CTS/src/readme.txt 
  * @author  
  * @version V1.0.0
  * @date    
  * @brief   Description of the USART Transmit_CTS example.
  ******************************************************************************

   @endverbatim


@par Example Description 

This example provides a basic communication between Board1_USARTy(USART1) and Board2_USARTz(USART2) 
using hardware flow control.USARTy and USARTz can be USART1 and USART2.

First, the USARTy sends TxBuffer to USARTz with CTS. The USARTz reads the received data with RTS and
store it into RxBuffer.
The received data is then compared with the send ones and the result of this 
comparison is stored in the "TransferStatus" variable.   

USARTy configured as follow:
  - BaudRate = 115200 baud  
  - Word Length = 8 Bits
  - One Stop Bit
  - No parity
  - Hardware flow control enabled CTS signals
  - Transmit enabled
  
USARTy and USARTz PINs connection as follow:
  - USART1_Tx.PA9    <------->   USART2_Rx.PB7
  - USART1_CTS.PA0   <------->   USART2_RTS.PA1

  