/**
  @page USART_Syschronous USART Syschronous example
  
  @verbatim
  ******************************************************************************
  * @file    USART/Syschronous/src/readme.txt 
  * @author  
  * @version V1.0.0
  * @date    
  * @brief   Description of the USART Syschronous example.
  ******************************************************************************

   @endverbatim


@par Example Description 

This example provides a basic communication between USARTy (Synchronous mode) 
and SPIy using flags. USARTy and SPIy can be USART1 and SPI1.

First, the USARTy sends data from TxBuffer1 buffer to SPIy using USARTy TXE flag.
Data received, using RXNE flag, by SPIy is stored in RxBuffer2 then compared with
the sent ones and the result of this comparison is stored in the "TransferStatus1" 
variable.
 
Then, the SPIy sends data from TxBuffer2 buffer to USARTy using SPIy TXE flag.
Data received, using RXNE flag, by USARTy is stored in RxBuffer1 then compared with
the sent ones and the result of this comparison is stored in the "TransferStatus2" 

USARTy configured as follow:
  - BaudRate = 115200 baud  
  - Word Length = 8 Bits
  - One Stop Bit
  - No parity
  - Hardware flow control disabled (RTS and CTS signals)
  - Receive and transmit enabled
  - USART Clock enabled
  - USART CPOL: Clock is active high
  - USART CPHA: Data is captured on the second edge 
  - USART LastBit: The clock pulse of the last data bit is output to the SCLK pin

SPIy configured as follow:
  - Direction = 2 Lines FullDuplex
  - Mode = Slave Mode
  - DataSize = 8 Bits
  - CPOL = Clock is active high
  - CPHA = Data is captured on the second edge 
  - NSS = NSS Software
  - First Bit = First Bit is the LSB  
  
USARTy and SPIy PINs connection as follow:
  - USART1_Tx.PA9    <------->   SPI1_MOSI.PA7
  - USART1_Rx.PA10   <------->   SPI1_MISO.PA6
  - USART1_CK.PA4    <------->   SPI1_SCK.PA5
  