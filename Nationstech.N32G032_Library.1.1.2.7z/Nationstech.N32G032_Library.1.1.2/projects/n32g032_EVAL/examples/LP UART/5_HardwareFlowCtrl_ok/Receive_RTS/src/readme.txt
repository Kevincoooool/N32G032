/**
  @page LPUART_Receive_RTS LPUART Receive_RTS example
  
  @verbatim
  ******************************************************************************
  * @file    LPUART/Receive_RTS/src/readme.txt 
  * @author  
  * @version V1.0.0
  * @date    
  * @brief   Description of the LPUART Receive_RTS example.
  ******************************************************************************

   @endverbatim


@par Example Description 

This example provides a basic communication between Board1_LPUARTy and Board2_LPUARTz 
using hardware flow control.

First, the Board1_LPUARTy sends TxBuffer to Board2_LPUARTz with CTS. The Board2_LPUARTz
reads the received data with RTS and store it into RxBuffer.
The received data is then compared with the send ones and the result of this 
comparison is stored in the "TransferStatus" variable.   

LPUART configured as follow:
  - BaudRate = 9600 baud  
  - Word Length = 8 Bits
  - One Stop Bit
  - No parity
  - Hardware flow control enabled RTS signals
  - Receive enabled
  
Board1_LPUARTy and Board2_LPUARTz PINs connection as follow:
  - Board1_LPUART1_Tx.PB6    <------->   Board2_LPUART1_Rx.PB7
  - Board1_LPUART1_CTS.PA6   <------->   Board2_LPUART1_RTS.PB1
  