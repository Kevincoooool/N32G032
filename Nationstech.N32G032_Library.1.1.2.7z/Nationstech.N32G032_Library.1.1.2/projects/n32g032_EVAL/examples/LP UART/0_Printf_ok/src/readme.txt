/**
  @page LPUART_Printf LPUART Printf example
  
  @verbatim
  ******************************************************************************
  * @file    LPUART/Printf/src/readme.txt 
  * @author  
  * @version V1.0.0
  * @date    
  * @brief   Description of the LPUART Printf example.
  ******************************************************************************

   @endverbatim


@par Example Description 

This example provides a basic communication between LPUARTx and PC using flags.
LPUARTx can be LPUART1.

The LPUARTx sends TxBuffer to PC. 
The LPUARTx receive data from PC.  

LPUARTx configured as follow:
  - BaudRate = 115200 baud  
  - Word Length = 8 Bits
  - One Stop Bit
  - No parity
  - Hardware flow control disabled (RTS and CTS signals)
  - Receive and transmit enabled
  
LPUARTx PINs connection as follow:
  - LPUART1_Tx.PA1 
  - LPUART1_Rx.PA0
  