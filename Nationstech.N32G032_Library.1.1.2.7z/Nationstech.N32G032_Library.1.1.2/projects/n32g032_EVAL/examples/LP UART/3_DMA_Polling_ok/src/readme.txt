/**
  @page LPUART_DMA_Polling LPUART DMA_Polling example
  
  @verbatim
  ******************************************************************************
  * @file    LPUART/DMA_Polling/src/readme.txt 
  * @author  
  * @version V1.0.0
  * @date    
  * @brief   Description of the LPUART DMA_Polling example.
  ******************************************************************************

   @endverbatim


@par Example Description 

This example provides a basic communication between LPUARTy and USARTz using DMA 
capability. LPUARTy and USARTz can be LPUART1 and USART1.

First, the DMA transfers data from TxBuffer2 buffer to USARTz Transmit data 
register, then this data is sent to LPUARTy. Data received by LPUARTy is transferred
by DMA and stored in RxBuffer1 then compared with the send ones and the result 
of this comparison is stored in the "TransferStatus1" variable.
 
In the same time, the DMA transfers data from TxBuffer1 buffer to LPUARTy Transmit
data register, then this data is sent to USARTz. Data received by USARTz is
transferred by DMA and stored in RxBuffer2 then compared with the send ones and
the result of this comparison is stored in the "TransferStatus2" variable.    

LPUARTy and USARTz configured as follow:
  - BaudRate = 115200 baud  
  - Word Length = 8 Bits
  - One Stop Bit
  - No parity
  - Hardware flow control disabled (RTS and CTS signals)
  - Receive and transmit enabled
  
LPUARTy and USARTz PINs connection as follow:
  - LPUART1_Tx.PA1   <------->   USART1_Rx.PA10
  - LPUART1_Rx.PA0   <------->   USART1_Tx.PA9
  