/**
  @page LPUART_Polling LPUART Polling example
  
  @verbatim
  ******************************************************************************
  * @file    LPUART/Polling/src/readme.txt 
  * @author  
  * @version V1.0.0
  * @date    
  * @brief   Description of the LPUART Polling example.
  ******************************************************************************

   @endverbatim


@par Example Description 

This example provides a basic communication between LPUARTy and USARTz using flags.
LPUARTy and USARTz can be LPUART1 and USART1.

First, the LPUARTy sends TxBuffer to USARTz. The USARTz reads the received data and
store it into RxBuffer.
The received data is then compared with the send ones and the result of this 
comparison is stored in the "TransferStatus" variable.   

LPUARTy and USARTz configured as follow:
  - BaudRate = 115200 baud  
  - Word Length = 8 Bits
  - One Stop Bit
  - No parity
  - Hardware flow control disabled (RTS and CTS signals)
  - Receive and transmit enabled
  
LPUARTy and USARTz PINs connection as follow:
  - LPUART1_Tx.PA1   <------->   USART1_Rx.PA10
  - LPUART1_Rx.PA0   <------->   USART1_Tx.PA9
  