/**
  @page LPUART_WakeUpFromSTOP LPUART Wake up from STOP mode example
  
  @verbatim
  ******************************************************************************
  * @file    LPUART/WakeUpFromSTOP/src/readme.txt 
  * @author  
  * @version V1.0.0
  * @date    
  * @brief   Description of the LPUART Wake up from STOP mode example.
  ******************************************************************************

   @endverbatim


@par Example Description 

This example provides a basic communication between LPUARTx and PC. LPUARTx can be 
LPUART1.
MCU enters STOP mode and is awoken by PC which sends the proper data to wake up MCU.
When the proper wake-up event is recognized, the WUF interrupt is triggered which 
wakes up MCU.

To confirm its wake up, MCU sends a confirmation message to PC which checks it is 
the expected message.
This cycle is repeated 4 times to verify 4 different events
1 wake-up by start bit detection
2 wake-up by RXNE detection
3 wake-up by a configurable received byte match
4 wake-up by a programmed 4-Byte frame match

LPUARTx configured as follow:
  - BaudRate = 9600 baud  
  - Word Length = 8 Bits
  - One Stop Bit
  - No parity
  - Hardware flow control disabled (RTS and CTS signals)
  - Receive and transmit enabled
  
LPUARTx PINs connection as follow:
  - LPUART1_Tx.PA1 
  - LPUART1_Rx.PA0
  