/*****************************************************************************
 * Copyright (c) 2019, Nations Technologies Inc.
 *
 * All rights reserved.
 * ****************************************************************************
 *
 * Redistribution and use in source and binary forms, with or without
 * modification, are permitted provided that the following conditions are met:
 *
 * - Redistributions of source code must retain the above copyright notice,
 * this list of conditions and the disclaimer below.
 *
 * Nations' name may not be used to endorse or promote products derived from
 * this software without specific prior written permission.
 *
 * DISCLAIMER: THIS SOFTWARE IS PROVIDED BY NATIONS "AS IS" AND ANY EXPRESS OR
 * IMPLIED WARRANTIES, INCLUDING, BUT NOT LIMITED TO, THE IMPLIED WARRANTIES OF
 * MERCHANTABILITY, FITNESS FOR A PARTICULAR PURPOSE AND NON-INFRINGEMENT ARE
 * DISCLAIMED. IN NO EVENT SHALL NATIONS BE LIABLE FOR ANY DIRECT, INDIRECT,
 * INCIDENTAL, SPECIAL, EXEMPLARY, OR CONSEQUENTIAL DAMAGES (INCLUDING, BUT NOT
 * LIMITED TO, PROCUREMENT OF SUBSTITUTE GOODS OR SERVICES; LOSS OF USE, DATA,
 * OR PROFITS; OR BUSINESS INTERRUPTION) HOWEVER CAUSED AND ON ANY THEORY OF
 * LIABILITY, WHETHER IN CONTRACT, STRICT LIABILITY, OR TORT (INCLUDING
 * NEGLIGENCE OR OTHERWISE) ARISING IN ANY WAY OUT OF THE USE OF THIS SOFTWARE,
 * EVEN IF ADVISED OF THE POSSIBILITY OF SUCH DAMAGE.
 * ****************************************************************************/

/**
 * @file main.c
 * @author Nations Solution Team
 * @version v1.0.0
 *
 * @copyright Copyright (c) 2019, Nations Technologies Inc. All rights reserved.
 */
#include "main.h"
#define SYSCLK_USE_HSI     0
#define SYSCLK_USE_HSE     1

// The following is the corresponding relationship of port, TSC channel, pulse data and key of this demo.
/*  port <------->  TSC channel     <-------> 	    pulse data buffer  				<-------> 	key in
   board PC8	 <------->  TSC channel 10  <-------> 	tsc_etr_key.ChannelDeltaEtrCnt[0]  	<-------> 	KEY "0"
        PC9  <-------> 	TSC channel 11	<------->	tsc_etr_key.ChannelDeltaEtrCnt[1]	<------->	KEY "*"
        PC12 <------->	TSC channel 14	<------->	tsc_etr_key.ChannelDeltaEtrCnt[2]	<------->	KEY "3"
        PD2  <------->	TSC channel 15	<------->	tsc_etr_key.ChannelDeltaEtrCnt[3]	<------->	KEY "2"
        PD4  <------->	TSC channel 16	<------->	tsc_etr_key.ChannelDeltaEtrCnt[4]	<------->	KEY "1"
        PD5  <------->	TSC channel 17	<------->	tsc_etr_key.ChannelDeltaEtrCnt[5]	<------->	KEY "6"
        PD6  <------->	TSC channel 18	<------->	tsc_etr_key.ChannelDeltaEtrCnt[6]	<------->	KEY "5"
        PD7  <------->	TSC channel 19	<------->	tsc_etr_key.ChannelDeltaEtrCnt[7]	<------->	KEY "4"
        PB6  <------->	TSC channel 20	<------->	tsc_etr_key.ChannelDeltaEtrCnt[8]	<------->	KEY "9"
        PB7  <------->	TSC channel 21	<------->	tsc_etr_key.ChannelDeltaEtrCnt[9]	<------->	KEY "8"
        PB8  <------->	TSC channel 22	<------->	tsc_etr_key.ChannelDeltaEtrCnt[10]	<------->	KEY "7"
        PB9  <------->	TSC channel 23	<------->	tsc_etr_key.ChannelDeltaEtrCnt[11]	<------->	KEY "#"
        */
typedef enum
{
    KEY_IDLE, // key not valid
    KEY_PRESS // key valid
} TSC_ETR_KEY_STATUS;
#define SUM_NUM  10
typedef struct
{
    uint32_t EtrCnt;                     // ETR value of this time which is equal to TIM2->CNT.
    uint32_t EtrCntPre;                  // ETR value of last time which is equal to TIM2->CNT.
    uint32_t DeltaEtrCnt;                // The number of pulses by the difference of two times.
    uint32_t ChannelDeltaEtrCnt[12][SUM_NUM]; // 12 channel;100us x 10 samples
    uint32_t ChannelDeltaEtrCntSum[12];  // Summation of 10 samples for each channel.
    uint32_t KeyValid[12];               // Key valid status of this time for each channel.
    uint32_t KeyValidPre[12];            // Key valid status of last time for each channel.
    uint32_t KeyValidHoldCnt[12];        // Key valid status hold up to the count continuously will be considered valid.

} TSC_ETR_KEY_PARA;

TSC_ETR_KEY_PARA tsc_etr_key;         // The struct is the about the process of key recognition by ETR.
uint32_t key_status;                  // Key recognition result of this time.
uint32_t key_status_pre;              // Key recognition result of last time.
bool b_one_cycle_sample_flag = false; // Calculate after completing 10 samples for each channel.
uint8_t flag_led             = 0;     // The flag of led blink.
uint8_t b_10ms_flag          = 0;     // The flag of 10ms.
uint8_t enter_stop_mode_flag = 0;//The flag of entering stop mode. 

/**
 * @brief  Selects PLL clock as System clock source and configure HCLK, PCLK2
 *         and PCLK1 prescalers.
 */
void SetSysClockToPLL(uint32_t freq, uint8_t src)
{
    uint32_t pllmul;
    uint32_t plldiv = RCC_PLLOUT_DIV_1;
    uint32_t latency;
    uint32_t pclk1div, pclk2div;
    ErrorStatus HSEStartUpStatus;
    ErrorStatus HSIStartUpStatus;
    if (HSE_VALUE != 8000000)
    {
        /* HSE_VALUE == 8000000 is needed in this project! */
        while (1);
    }

    /* SYSCLK, HCLK, PCLK2 and PCLK1 configuration
     * -----------------------------*/
    /* RCC system reset(for debug purpose) */
    RCC_DeInit();

    if (src == SYSCLK_USE_HSI) 
    {
        /* Enable HSI */
        RCC_ConfigHsi(RCC_HSI_ENABLE);

        /* Wait till HSI is ready */
        HSIStartUpStatus = RCC_WaitHsiStable();

        if (HSIStartUpStatus != SUCCESS)
        {
            /* If HSI fails to start-up, the application will have wrong clock
               configuration. User can add here some code to deal with this
               error */

            /* Go to infinite loop */
            while (1);
        }

    }
		else if (src == SYSCLK_USE_HSE) 
    {
        /* Enable HSE */
        RCC_ConfigHse(RCC_HSE_ENABLE);

        /* Wait till HSE is ready */
        HSEStartUpStatus = RCC_WaitHseStable();

        if (HSEStartUpStatus != SUCCESS)
        {
            /* If HSE fails to start-up, the application will have wrong clock
               configuration. User can add here some code to deal with this
               error */

            /* Go to infinite loop */
            while (1);
        }

    }

    

    switch (freq)
    {
        case 32000000:
            latency  = FLASH_LATENCY_1;
            if(src == SYSCLK_USE_HSI)
            {
                pllmul = RCC_PLL_MUL_8;
            }
            else if(src == SYSCLK_USE_HSE)
            {
                pllmul = RCC_PLL_MUL_8;
            }
            pclk1div = RCC_HCLK_DIV2;
            pclk2div = RCC_HCLK_DIV1;
            break;
        case 48000000:
            latency  = FLASH_LATENCY_2;
            if(src == SYSCLK_USE_HSI)
            {
              pllmul = RCC_PLL_MUL_12;
            }
            else if(src == SYSCLK_USE_HSE)
            {
               pllmul = RCC_PLL_MUL_12;
            }
            pclk1div = RCC_HCLK_DIV2;
            pclk2div = RCC_HCLK_DIV1;
            break;
        default:
            while (1);
    }

    FLASH_SetLatency(latency);

    /* HCLK = SYSCLK */
    RCC_ConfigHclk(RCC_SYSCLK_DIV1);

    /* PCLK2 = HCLK */
    RCC_ConfigPclk2(pclk2div);

    /* PCLK1 = HCLK */
    RCC_ConfigPclk1(pclk1div);
    if(src == SYSCLK_USE_HSE)
		{
			RCC_ConfigPll(RCC_PLL_SRC_HSE,pllmul, RCC_PLL_PRE_2, plldiv);
			
		}
		else
		{
			RCC_ConfigPll(RCC_PLL_SRC_HSI,pllmul, RCC_PLL_PRE_2, plldiv);
		}
		
    

    /* Enable PLL */
    RCC_EnablePll(ENABLE);

    /* Wait till PLL is ready */
   // while (RCC_GetFlagStatus(RCC_CTRL_FLAG_PLLRDF) == RESET);
     /* Wait till PLL is ready */
    while ((RCC->CTRL & RCC_CTRL_PLLRDF) == 0)
    {
    }
    /* Select PLL as system clock source */
    RCC_ConfigSysclk(RCC_SYSCLK_SRC_PLLCLK);

    /* Wait till PLL is used as system clock source */
    while (RCC_GetSysclkSrc() != RCC_CFG_SCLKSTS_PLL);
}
/******************************************************************/
/***
 * @brief    Configure the ports of TSC channels for sample.
 */
void tsc_gpio_init(void)
{
     GPIO_InitType GPIO_InitStruct;

    RCC_EnableAPB2PeriphClk(RCC_APB2_PERIPH_GPIOA, ENABLE);

    // tsc chn 0 1
    GPIO_InitStruct.Pin       = GPIO_PIN_4;
    GPIO_InitStruct.GPIO_Mode = GPIO_MODE_ANALOG; // GPIO_Mode_AIN ,GPIO_Mode_IN_FLOATING,GPIO_Mode_IPD,GPIO_Mode_IPU
    GPIO_InitPeripheral(GPIOA, &GPIO_InitStruct);

    RCC_EnableAPB2PeriphClk(RCC_APB2_PERIPH_GPIOB, ENABLE);
    // tsc chn 20-23
    GPIO_InitStruct.Pin       = GPIO_PIN_6 | GPIO_PIN_7 | GPIO_PIN_8 | GPIO_PIN_9;
    GPIO_InitStruct.GPIO_Mode = GPIO_MODE_ANALOG; // GPIO_Mode_AIN ,GPIO_Mode_IN_FLOATING,GPIO_Mode_IPD,GPIO_Mode_IPU
    GPIO_InitPeripheral(GPIOB, &GPIO_InitStruct);

    RCC_EnableAPB2PeriphClk(RCC_APB2_PERIPH_GPIOC, ENABLE);
    // tsc chn 10/11/14
    GPIO_InitStruct.Pin       = GPIO_PIN_8 | GPIO_PIN_9 | GPIO_PIN_12;
    GPIO_InitStruct.GPIO_Mode = GPIO_MODE_ANALOG; // GPIO_Mode_AIN ,GPIO_Mode_IN_FLOATING,GPIO_Mode_IPD,GPIO_Mode_IPU
    GPIO_InitPeripheral(GPIOC, &GPIO_InitStruct);

    RCC_EnableAPB2PeriphClk(RCC_APB2_PERIPH_GPIOD, ENABLE);
    // tsc chn 15-19
    GPIO_InitStruct.Pin       = GPIO_PIN_2 | GPIO_PIN_4 | GPIO_PIN_5 | GPIO_PIN_6 | GPIO_PIN_7;
    GPIO_InitStruct.GPIO_Mode = GPIO_MODE_ANALOG; // GPIO_Mode_AIN ,GPIO_Mode_IN_FLOATING,GPIO_Mode_IPD,GPIO_Mode_IPU
    GPIO_InitPeripheral(GPIOD, &GPIO_InitStruct);

    GPIO_InitStruct.Pin       = GPIO_PIN_0;
    GPIO_InitStruct.GPIO_Mode = GPIO_MODE_INPUT; // GPIO_Mode_AIN ,GPIO_Mode_IN_FLOATING,GPIO_Mode_IPD,GPIO_Mode_IPU
    GPIO_InitStruct.GPIO_Pull = GPIO_PULL_UP;
	GPIO_InitPeripheral(GPIOA, &GPIO_InitStruct);

    RCC_EnableAPB2PeriphClk(RCC_APB2_PERIPH_GPIOB | RCC_APB2_PERIPH_AFIO, ENABLE);
    GPIO_InitStruct.Pin        = GPIO_PIN_7;
	//GPIO_InitStruct.GPIO_Current = GPIO_DC_2mA;
    GPIO_InitStruct.GPIO_Mode  = GPIO_MODE_AF_PP; // GPIO_Mode_AIN ,GPIO_Mode_IN_FLOATING,GPIO_Mode_IPD,GPIO_Mode_IPU
    //GPIO_InitStruct.GPIO_Slew_Rate = GPIO_SPEED_HIGH;
	//GPIO_InitStruct.GPIO_Alternate = GPIO_AF9_TSC;
	GPIO_InitPeripheral(GPIOB,&GPIO_InitStruct);
}
/******************************************************************/
/***
 * @brief    Get ETR counts by counters of timer4.
 */

void tsc_tim4_init(void)
{
    RCC_EnableAPB1PeriphClk(RCC_APB1_PERIPH_TIM4, ENABLE);

    // Reset timer to default.
    TIM_DeInit(TIM4);

    TIM4->CTRL1 |= TIM_CNT_MODE_UP;
    TIM4->CTRL1 |= TIM_OPMODE_REPET;
    TIM4->CTRL1 &= ~TIM_CTRL1_UPDIS;
    TIM4->CTRL1 &= ~TIM_CTRL1_UPRS;
    TIM4->CTRL1 |= TIM_CTRL1_ARPEN;
    TIM4->PSC = (u16)(0);
    TIM4->AR  = (u16)(65535);

    TIM4->SMCTRL |= TIM_SLAVE_MODE_TRIG;
    TIM4->SMCTRL |= TIM_SMCTRL_EXCEN;
    TIM4->SMCTRL |= TIM_MASTER_SLAVE_MODE_ENABLE;

    TIM4->CNT = 0;
    TIM4->SMCTRL &= ~TIM_SMCTRL_EXTPS;
    TIM4->SMCTRL |= TIM_EXT_TRG_PSC_OFF;
    TIM4->EVTGEN |= TIM_EVT_SRC_UPDATE;

    TIM_Enable(TIM4, ENABLE);
    TIM4->STS = 0;
}
/******************************************************************/
/***
 * @brief    Total function of software detection configuration.
 */
void tsc_sw_config(void)
{
    RCC_EnableAPB1PeriphClk(RCC_APB1_PERIPH_TSC, ENABLE);
    tsc_gpio_init();
    tsc_tim4_init();
    TSC_SW_Init_Skip();
}
/******************************************************************/
/***
 * @brief    Configure the ports of led.
 */
void led_gpio_init(void)
{
    GPIO_InitType GPIO_InitStructure;
	
    GPIO_InitStruct(&GPIO_InitStructure);

	RCC_EnableAPB2PeriphClk(RCC_APB2_PERIPH_GPIOB, ENABLE); // PB0 for LED1
	
	GPIO_InitStructure.Pin        = GPIO_PIN_0;
	//GPIO_InitStructure.GPIO_Current = GPIO_DC_4mA;
	GPIO_InitStructure.GPIO_Pull    = GPIO_NO_PULL;
	GPIO_InitStructure.GPIO_Mode  = GPIO_MODE_OUTPUT_PP;
  GPIO_InitPeripheral(GPIOB,&GPIO_InitStructure); 


}
/******************************************************************/
/***
 * @brief    Toggle the led to blink.
 */
void led_blink(void)
{
    if (flag_led == 0)
    {
        GPIO_ResetBits(GPIOB, GPIO_PIN_0);
        flag_led = 1;
    }
    else
    {
        GPIO_SetBits(GPIOB, GPIO_PIN_0);
        flag_led = 0;
    }
}
/******************************************************************/
/***
 * @brief    Initialize the variables of TSC.
 */
void TscEtrKeyInit(void)
{
    memset((void*)&tsc_etr_key, 0, sizeof(TSC_ETR_KEY_PARA));
    key_status     = KEY_IDLE;
    key_status_pre = KEY_IDLE;
}
/******************************************************************/
/***
 * @brief Set the Maximum and Minimum pulses of thresholds according to different channels if necessary.
          Judge whether the key is valid this time according to the threshold value.
 * @param channel Select the channel.
 * @return KEY_IDLE:key not valid,KEY_PRESS:key valid.
 */
TSC_ETR_KEY_STATUS KeyEtrCntThesholdCompare(uint32_t channel)
{
    uint32_t max_theshold = 0;
    uint32_t min_theshold = 0;

    switch (channel)
    {
    case 0:
        min_theshold = 50;
        max_theshold = 480;
        break;
    case 1:
        min_theshold = 50;
        max_theshold = 550;
        break;
    case 2:
        min_theshold = 50;
        max_theshold = 600;
        break;
    case 3:
        min_theshold = 50;
        max_theshold = 600;
        break;
    case 4:
        min_theshold = 50;
        max_theshold = 600;
        break;
    case 5:
        min_theshold = 50;
        max_theshold = 500;
        break;
    case 6:
        min_theshold = 50;
        max_theshold = 500;
        break;
    case 7:
        min_theshold = 50;
        max_theshold = 600;
        break;
    case 8:
        min_theshold = 50;
        max_theshold = 500;
        break;
    case 9:
        min_theshold = 50;
        max_theshold = 500;
        break;
    case 10:
        min_theshold = 50;
        max_theshold = 500;
        break;
    case 11:
        min_theshold = 50;
        max_theshold = 480;
        break;
    default:
        break;
    }
   // if ((tsc_etr_key.ChannelDeltaEtrCntSum[channel] > min_theshold) & (tsc_etr_key.ChannelDeltaEtrCntSum[channel] < max_theshold))
     if((tsc_etr_key.ChannelDeltaEtrCntSum[channel] > 50)&(tsc_etr_key.ChannelDeltaEtrCntSum[channel] < 400))
    {
        return KEY_PRESS;
    }
    else
    {
        return KEY_IDLE;
    }
}
/**
 * @brief  Calculate the summation pulses of the last ten times for each channel.If key valid status hold up to 3 times
 * continuously,It will be considered valid.
 */
void TscEtrKey10msTask(void)
{
    uint32_t i = 0, j = 0;

    if (!b_one_cycle_sample_flag)
        return;

    for (i = 0; i < 12; i++)
    {
        tsc_etr_key.ChannelDeltaEtrCntSum[i] = 0;
        for (j = 0; j < SUM_NUM; j++)
        {
            tsc_etr_key.ChannelDeltaEtrCntSum[i] += tsc_etr_key.ChannelDeltaEtrCnt[i][j];
        }

        tsc_etr_key.KeyValid[i] = KeyEtrCntThesholdCompare(i);
        if (tsc_etr_key.KeyValidPre[i] != tsc_etr_key.KeyValid[i])
        {
            tsc_etr_key.KeyValidPre[i]     = tsc_etr_key.KeyValid[i];
            tsc_etr_key.KeyValidHoldCnt[i] = 0;
        }
        if (++tsc_etr_key.KeyValidHoldCnt[i] >= 3)
        {
            tsc_etr_key.KeyValidHoldCnt[i] = 0;
            if (tsc_etr_key.KeyValid[i])
            {
                key_status |= 1 << i;
            }
            else
            {
                key_status &= ~(1 << i);
            }
        }
    }
}
/**
 * @brief  Print corresponding information according to key status.
 * @param key_status Key recognition result of this time.
 */
void KeyPrint(uint32_t key_status)
{
    uint32_t i = 0;

    if (key_status == 0)
    {
        printf("No key Press\r\n");
        return;
    }

    for (i = 0; i < 12; i++)
    {
        if (key_status & (1 << i))
        {
            if (i == 0)
                printf("Key 0 Press\r\n");
            else if (i == 1)
                printf("Key * Press\r\n");
            else if (i == 2)
                printf("Key 3 Press\r\n");
            else if (i == 3)
                printf("Key 2 Press\r\n");
            else if (i == 4)
                printf("Key 1 Press\r\n");
            else if (i == 5)
                printf("Key 6 Press\r\n");
            else if (i == 6)
                printf("Key 5 Press\r\n");
            else if (i == 7)
                printf("Key 4 Press\r\n");
            else if (i == 8)
                printf("Key 9 Press\r\n");
            else if (i == 9)
                printf("Key 8 Press\r\n");
            else if (i == 10)
                printf("Key 7 Press\r\n");
            else if (i == 11)
                printf("Key # Press\r\n");
        }
    }
}
/**
 * @brief  Processing function per 10ms about TSC.
 */
void TscEtrCntProc(void)
{
    static uint32_t Cnt1s = 0;

    if (b_10ms_flag)
    {
        b_10ms_flag = 0;
        TscEtrKey10msTask();

        if (key_status != key_status_pre)
        {
            key_status_pre = key_status;
            KeyPrint(key_status);
        }
        if (++Cnt1s >= 100) // 1s
        {
            Cnt1s = 0;
            led_blink();
        }
    }
}
/**
 * @brief  Timer3 initialization configuration.
 */
void tim3_init(uint16_t Period, uint16_t Prescaler)
{
    TIM_TimeBaseInitType timInitStruct;
    NVIC_InitType NVIC_InitStructure;

    RCC_EnableAPB1PeriphClk(RCC_APB1_PERIPH_TIM3, ENABLE);

    timInitStruct.Period    = Period;
    timInitStruct.Prescaler = Prescaler;
    timInitStruct.ClkDiv    = 0;
    timInitStruct.CntMode   = TIM_CNT_MODE_UP;
    TIM_InitTimeBase(TIM3, &timInitStruct);

    TIM_ConfigInt(TIM3, TIM_INT_UPDATE, ENABLE);

    NVIC_InitStructure.NVIC_IRQChannel                   = TIM3_IRQn;
    NVIC_InitStructure.NVIC_IRQChannelPriority           = 1;
    NVIC_InitStructure.NVIC_IRQChannelCmd                = ENABLE;
    NVIC_Init(&NVIC_InitStructure);

    TIM_Enable(TIM3, ENABLE);
}
/**
  * @brief  TIM3 interrupt process function each 100us.Get the TIM2->CNT value, and Calculate the number of pulses by
  the difference of two times. Then take the delta pules into the buffer of last channel and toggle to new channel.
  */
void TIM3_IRQHandler(void)
{
    static uint32_t Cnt10ms = 0;
	static uint32_t Cnt10s = 0;
    static uint32_t Channel = 11; // start from channel 10
    static uint32_t num     = 0;

    if (TIM_GetIntStatus(TIM3, TIM_INT_UPDATE) != RESET)
    {
        TIM_ClrIntPendingBit(TIM3, TIM_INT_UPDATE);
        if (++Cnt10ms >= 100) // 10ms
        {
            b_10ms_flag = 1;
            Cnt10ms     = 0;
        }
		if(++Cnt10s >= 100000) //10s 
        {
            Cnt10s = 0;
            enter_stop_mode_flag = 1; //10S Enter stop
        }
        tsc_etr_key.EtrCntPre = tsc_etr_key.EtrCnt;

        // Get the value of TIM2->CNT.
        tsc_etr_key.EtrCnt = TIM4->CNT;

        // Calculate the number of pulses by the difference of two times.
        if (tsc_etr_key.EtrCnt >= tsc_etr_key.EtrCntPre)
            tsc_etr_key.DeltaEtrCnt = tsc_etr_key.EtrCnt - tsc_etr_key.EtrCntPre;
        else
            tsc_etr_key.DeltaEtrCnt = tsc_etr_key.EtrCnt + 0xFFFF - tsc_etr_key.EtrCntPre;

        // Take the delta pules into the buffer of last channel.
        if (Channel == 10)
        {
            tsc_etr_key.ChannelDeltaEtrCnt[11][num] = tsc_etr_key.DeltaEtrCnt;
            if (++num >= SUM_NUM)
            {
                num = 0;
                b_one_cycle_sample_flag = true;
            }
        }
        else if (Channel == 11)
        {
            tsc_etr_key.ChannelDeltaEtrCnt[0][num] = tsc_etr_key.DeltaEtrCnt;
        }
        else // 14-23
        {
            tsc_etr_key.ChannelDeltaEtrCnt[Channel - 13][num] = tsc_etr_key.DeltaEtrCnt;
        }

        // Toggle to new channel.
        //TSC_SW_SwtichChn_Skip(Channel);

        Channel++; // TSC10-11,14-23
        if (Channel == 12)
        {
            Channel = 14;
        }
        else if (Channel == 24)
        {
            Channel = 10;
        }
    }
}
void pwr_wakeup_gpio_init(void)
{
    GPIO_InitType GPIO_InitStruct;
	RCC_EnableAPB2PeriphClk(RCC_APB2_PERIPH_GPIOA | RCC_APB2_PERIPH_AFIO, ENABLE);
	GPIO_InitStruct.Pin   = GPIO_PIN_0;
	GPIO_InitStruct.GPIO_Pull = GPIO_PULL_UP;
	GPIO_InitStruct.GPIO_Mode  = GPIO_MODE_INPUT;
	GPIO_InitPeripheral(GPIOA,&GPIO_InitStruct);
}

void tsc_exti21_init(void)
{
    EXTI_InitType EXTI_InitStruct;

    EXTI_InitStruct.EXTI_Line = EXTI_LINE21;
    EXTI_InitStruct.EXTI_LineCmd = ENABLE;
    EXTI_InitStruct.EXTI_Mode = EXTI_Mode_Interrupt;
    EXTI_InitStruct.EXTI_Trigger = EXTI_Trigger_Falling;

    EXTI_InitPeripheral(&EXTI_InitStruct);
}

void pwr_wakeup_exti0_init(void)
{
    EXTI_InitType EXTI_InitStruct;
    GPIO_ConfigEXTILine(GPIOA_PORT_SOURCE, GPIO_PIN_SOURCE0);
    EXTI_InitStruct.EXTI_Line = EXTI_LINE0;
    EXTI_InitStruct.EXTI_LineCmd = ENABLE;
    EXTI_InitStruct.EXTI_Mode = EXTI_Mode_Interrupt;
    EXTI_InitStruct.EXTI_Trigger = EXTI_Trigger_Falling;

    EXTI_InitPeripheral(&EXTI_InitStruct);


    /* Configure NVIC interrupt.*/
    NVIC_InitType NVIC_InitStructure;
    
    /* Configure the source of interrupt.*/
    NVIC_InitStructure.NVIC_IRQChannel = EXTI0_1_IRQn;
    /* Configure priority. */
    NVIC_InitStructure.NVIC_IRQChannelPriority = 2;
    /* Enable interrupt channel. */
    NVIC_InitStructure.NVIC_IRQChannelCmd = ENABLE;
    NVIC_Init(&NVIC_InitStructure);

}
void sys_gpio_deinit(GPIO_Module* GPIOx)
{
    GPIO_InitType GPIO_InitStruct;
	GPIO_InitStruct.Pin   = GPIO_PIN_ALL;
	GPIO_InitStruct.GPIO_Pull = GPIO_PULL_UP;
	GPIO_InitStruct.GPIO_Mode  = GPIO_MODE_INPUT;//GPIO_Mode_AIN ,GPIO_Mode_IN_FLOATING,GPIO_Mode_IPD,GPIO_Mode_IPU
    GPIO_InitPeripheral(GPIOx,&GPIO_InitStruct);
}

void sys_enter_pwr_stop(void)
{
    printf("sys_enter_pwr_stop\r\n");
    USART_DeInit(USART2);
    sys_gpio_deinit(GPIOA);
    sys_gpio_deinit(GPIOB);
    sys_gpio_deinit(GPIOC);
    sys_gpio_deinit(GPIOD);
    GPIO_DeInit(GPIOA);
    GPIO_DeInit(GPIOB);
    GPIO_DeInit(GPIOC);
    GPIO_DeInit(GPIOD);
    TIM_DeInit(TIM4);
    PWR_EnterSTOPMode(PWR_STOPPLUSE_ENABLE,PWR_STOPENTRY_WFI);   
}
void sys_exit_mode_stop(void)
{
    SetSysClockToPLL(32000000,SYSCLK_USE_HSI);
    USART_Config();
}
void TSC_IRQHandler(void)
{
    EXTI_ClrITPendBit(EXTI_LINE21);
    //pTSC_ext->tsc_thrhd0.base = pTSC_ext->tsc_sr.cnt_val;
    //pTSC_ext->tsc_thrhd0.delta = (pTSC_ext->tsc_thrhd0.base>>1);
    //printf("res %d K, chn_val 0x%02x\r\n", (res_curr+1)*125, pTSC_ext->tsc_sr.cnt_val);
    #if 0
    tsc_test_case1();
    pTSC_ext->tsc_sr.great_det = 1;
    pTSC_ext->tsc_sr.less_det = 1;
    #endif
}
/**
* @brief Set external 21 line interrupt remap to wake up from TSC low power mode.  
* @param void
* @return TSC_SUCCESS:success;Other values indicate an error.
*/
void tsc_alg_exti21_init(void)
{
    EXTI_InitType EXTI_InitStruct;

    // GPIO_EXTILineConfig(GPIO_PortSourceGPIOA, GPIO_PinSource4);
	//GPIO_ConfigEXTILine(GPIOC_PORT_SOURCE, GPIO_PIN_SOURCE8);
    EXTI_InitStruct.EXTI_Line    = EXTI_LINE21;
    EXTI_InitStruct.EXTI_LineCmd = ENABLE;
    EXTI_InitStruct.EXTI_Mode    = EXTI_Mode_Interrupt;
    EXTI_InitStruct.EXTI_Trigger = EXTI_Trigger_Falling;

    EXTI_InitPeripheral(&EXTI_InitStruct);
    // EXTI->IMR |= EXTI_LINE21;
    // EXTI->EMR |= EXTI_LINE21;
}

//stop mode
/**
* @brief Set touch channel parameters before entering into low power mode.
* @param TScChannelList:Enable List of touch channels that can be waked up. If 0, it means all channels that can be registered.
* @return TSC_SUCCESS:success;Other values indicate an error.
*/
int32_t tsc_alg_set_powerdown(uint32_t TscChannelList)

{
    uint32_t i, j, total_chns = 0;
    uint16_t base, delta, cur_cnt_value;
    //float times, f;
    TSC_ChnCfg ChnCfg       = {0};
    TSC_InitType InitDef = {0};

    //Turn off LSI to prevent affecting count of TSC hardware mode.
    RCC->CTRLSTS &= (~0x01);

    //Configure parameters of waking up by TSC hardware.  
    RCC_EnableAPB1PeriphClk(RCC_APB1_PERIPH_TSC, ENABLE);

    //Reset TSC module.
    RCC_EnableAPB1PeriphReset(RCC_APB1_PERIPH_TSC, ENABLE);
    //Clear reset.
    RCC_EnableAPB1PeriphReset(RCC_APB1_PERIPH_TSC, DISABLE);

    //Clear flag of reset.
    RCC->CTRLSTS |= RCC_CTRLSTS_PINRSTF | RCC_CTRLSTS_PORRSTF;

    // open rcc PWREN BKPEN
    RCC_EnableAPB1PeriphClk(RCC_APB1_PERIPH_PWR, ENABLE);

		/* Enable the LSE OSC32_IN PC14 */
		RCC_EnableLsi(DISABLE); // LSI is turned off here to ensure that only one clock is turned on
    RCC_ConfigLse(RCC_LSE_ENABLE);
		while (RCC_GetFlagStatus(RCC_LSCTRL_FLAG_LSERD) == RESET);

    //Configure RTC to enable TSC wake up and period.
    // i.    Wait until RTC_BASSE_ADDR+32��h64 bit 3 is 1 // wait wake last wakeup cnt operation done
    while (!(RTC->TSCWKUPCTRL & 0x00000008))
    {
    }
    // enter cfg wakeup cnt mode
    RTC->TSCWKUPCTRL = (uint32_t)0x00000004;

    // iii.  Write RTC_BASE_ADDR + 32��h68  32��h2fe // cfg tsc wakeup cnt
    RTC->TSCWKUPCNT = (uint32_t)0x2efa; //;//tsc wakeup module counting cycle = WAKUPCNT * LSE/LSI

    // iv.   Write RTC_BASE_ADDR + 32��h64  32��h0 // exit cfg wakeup cnt mode
    RTC->TSCWKUPCTRL = (uint32_t)0x00000000;

    while (!(RTC->TSCWKUPCTRL & 0x00000008))
    {
    }
    // v.    Write RTC_BASE_ADDR+32��h64, 32��h1 // open wakeup enable
    RTC->TSCWKUPCTRL = (uint32_t)0x00000001;

    //Stop to detect.
    TSC_Cmd(TSC, 0, DISABLE);

    for (i = TSC_CHN0, j = 0; i <= TSC_CHN23; i <<= 1, j++)
    {
        // if (g_register_chn_array[j])
        if (i == TscChannelList)//
        {
            //Reset TSC module.
            RCC_EnableAPB1PeriphReset(RCC_APB1_PERIPH_TSC, ENABLE);
            //Clear reset.
            RCC_EnableAPB1PeriphReset(RCC_APB1_PERIPH_TSC, DISABLE);

            total_chns |= i;

            InitDef.TSC_DetIntEnable = DISABLE;                 
            InitDef.TSC_GreatEnable  = DISABLE;                 
            InitDef.TSC_LessEnable   = DISABLE;                 
            InitDef.TSC_FilterCount  = TSC_HW_DET_FILTER_1;     
            InitDef.TSC_DetPeriod    = TSC_DET_PERIOD_32_32KHZ; //Set detection period.
            TSC_Init(TSC, &InitDef);
			
			TSC->RESR1 = 0x77007700; // Select the internal resistance of the corresponding channel as 126K.
			TSC->RESR2 = 0x77777777; // Select the internal resistance of the corresponding channel as 126K.

            //Enable channel and get the current value.
            TSC_GetChannelCfg(TSC, &ChnCfg, i);

            //Configure base and delta value of channel.
            ChnCfg.TSC_Base  = base;
            ChnCfg.TSC_Delta = delta;
            TSC_SetChannelCfg(TSC, &ChnCfg, i);

            //Start to detect.
            TSC_Cmd(TSC, i, ENABLE);

            //Wait for hardware to start to detect
            while (!TSC_GetStatus(TSC, TSC_STS_CNTVALUE))
                ;

            //Delay a little.
            cur_cnt_value = TSC_GetStatus(TSC, TSC_STS_CNTVALUE);

            //Stop to detect.
            TSC_Cmd(TSC, 0, DISABLE);

            ChnCfg.TSC_Base  = cur_cnt_value;
            ChnCfg.TSC_Delta = cur_cnt_value / 3; //Wake up when CNT value is less than base-delta. 
			//printf("cur_cnt_value = %d\r\n",cur_cnt_value);
						
			//Select the internal resistance of the corresponding channel as 126K.
			//ChnCfg.TSC_Base  = 108;
            //ChnCfg.TSC_Delta = 50;
            TSC_SetChannelCfg(TSC, &ChnCfg, i);

            break;
        }
    }

    /* Configure NVIC interrupt.*/
    NVIC_InitType NVIC_InitStructure;

    /* Configure the source of interrupt.*/
    NVIC_InitStructure.NVIC_IRQChannel = TSC_IRQn;
    /* Configure priority. */
    NVIC_InitStructure.NVIC_IRQChannelPriority = 1;
    /* Enable interrupt channel. */
    NVIC_InitStructure.NVIC_IRQChannelCmd = ENABLE;
    NVIC_Init(&NVIC_InitStructure);
	
    tsc_alg_exti21_init();

    InitDef.TSC_DetIntEnable = ENABLE;                  //Enable hardware detection.
    InitDef.TSC_GreatEnable  = DISABLE;                 //Disable detection with great than threshold.
    InitDef.TSC_LessEnable   = ENABLE;                  //Enable detection with less than threshold.
    InitDef.TSC_FilterCount  = TSC_HW_DET_FILTER_1;     
    InitDef.TSC_DetPeriod    = TSC_DET_PERIOD_32_32KHZ; //Must be consistent with the cycle of the above detection.
    TSC_Init(TSC, &InitDef);

    //Start hardware detection.
    TSC_Cmd(TSC, total_chns, ENABLE);

    return TSC_SUCCESS;
}

/**
 * @brief Assert failed function by user.
 * @param file The name of the call that failed.
 * @param line The source line number of the call that failed.
 */
#ifdef USE_FULL_ASSERT
void assert_failed(const uint8_t* expr, const uint8_t* file, uint32_t line)
{
    while (1)
    {
    }
}
#endif // USE_FULL_ASSERT

/**
 * @brief  Main program.
 */
int main(void)
{
    // HSE,SYSCLK = 8M * RCC_PLLMul_x, x:[2,3,...32],maximum frequency 48M
    SetSysClockToPLL(32000000,SYSCLK_USE_HSI);
    /* Enable Prefetch Buffer */
    FLASH->AC &= ~FLASH_AC_PRFTBFEN;

    /*Initialize USART as 115200 bps, 8 bit length,1 stop bit,no check bit,enable receive by interrupt */
    USART_Config();

    Usart_SendString(DEBUG_USARTx, "N32G032 startup ...\n");
    printf("N32G032\r\n");

	TscEtrKeyInit();
    tsc_sw_config();
	led_gpio_init(); // PB0 for LED1
    tim3_init(99, 71); // 72MH/(71+1)=1M Hz;1M Hz/(99+1)=100us

    while (1)
    {
		if(enter_stop_mode_flag)
        {
            enter_stop_mode_flag = 0;

			tsc_alg_set_powerdown(TSC_CHN10);
			GPIO_SetBits(GPIOB, GPIO_PIN_0);
							
            sys_enter_pwr_stop();

            sys_exit_mode_stop();
			 
			led_gpio_init();// PB0 for LED1
			GPIO_ResetBits(GPIOB, GPIO_PIN_0);
			
			TscEtrKeyInit();
			tsc_sw_config();
			tim3_init(99,71);//72MH/(71+1)=1M Hz;1M Hz/(99+1)=100us
        }
		else
		{
			TscEtrCntProc();
		}
    }
}
